<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete</title>
    <link rel="stylesheet" href="<?= base_url()?>assets/bootstrap/css/bootstrap.css">
    <script src="<?= base_url()?>assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
    <div class="container"><br><br>
    <h4><b>Klik Ok Untuk Menghapus <?php echo $product_name?></b></h4>
    <form action="<?php echo site_url('product/delete/'.$product_code);?>">
        <button type="submit" class="btn btn-secondary">OK</button>
    </form>
    </div>
</body>
</html>