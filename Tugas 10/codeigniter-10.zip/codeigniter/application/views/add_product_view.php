<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <link rel="stylesheet" href="<?= base_url()?>assets/bootstrap/css/bootstrap.css">
    <script src="<?= base_url()?>assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
<div class="container">
    <h1><center>Add New Product</center></h1>
    <div>
        <form action="<?php echo site_url ('product/save');?>" method="post">
        <div>
            <label>Product Name</label>
            <input type="text" name="product_name" placeholder="Product Name" class="form-control">
        </div>
        <div>
            <label>Price</label>
            <input type="text" name="product_price" placeholder="Price" class="form-control">
        </div><br>
        <button type="submit" class="btn btn-secondary">Submit</button>
        </form>
    </div>
</div>
</body>
</html>