<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit New Product</title>
    <link rel="stylesheet" href="<?= base_url()?>assets/bootstrap/css/bootstrap.css">
    <script src="<?= base_url()?>assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
    <div class="container">
    <h1><center>Edit New Product</center></h1>
    <div>
        <form action="<?php echo site_url ('product/update');?>" method="post">
        <div>
            <label>Product Name</label>
            <input class="form-control" type="text" name="product_name" value="<?php echo $product_name;?>" placeholder="Product Name">
        </div>
        <div>
            <label>Price</label>
            <input class="form-control" type="text" name="product_price" value="<?php echo $product_price;?>" placeholder="Price">
        </div>
        <input type="hidden" name="product_code" value="<?php echo $product_code?>">
        <br><button type="submit" class="btn btn-secondary">Submit</button>
        </form>
    </div>
    </div>
</body>
</html>