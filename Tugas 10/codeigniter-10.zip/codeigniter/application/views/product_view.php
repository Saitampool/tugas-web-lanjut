<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link rel="stylesheet" href="<?= base_url()?>assets/bootstrap/css/bootstrap.css">
    <script src="<?= base_url()?>assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
<h1><center>Product List</center></h1>
<div class="container">
    <div class="input-group">
        <div class="form-outline"><form method="post" action="<?= base_url() ?>index.php/product/index"></div>
            <input type="text" name="search" value="<?= $search ?>" class="form-control">
            <input type="submit" name="submit" value="Submit" class="btn btn-secondary" type="button">
        </form>
    </div><br>
<a href="<?php echo site_url('product/add_new');?>" class="btn btn-primary">Add Product</a><br/><br/>
<table class="table table-hover">
    <thead>
        <tr>
            <th>NO</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $count = $row + 1;
        foreach ($product->result() as $row) :
        ?>
    <tr>
        <th><?php echo $count;?></th>
        <td><?php echo $row->product_name;?></td>
        <td><?php echo number_format($row->product_price);?></td>
        <td>
            <a href="<?php echo site_url ('product/get_edit/'.$row->product_code);?>" class="btn btn-warning">Update</a>
            <a href="<?php echo site_url ('product/get_delete/'.$row->product_code);?>" class="btn btn-danger">Delete</a>
        </td>
    </tr>
        <?php 
        $count++;
        endforeach;
        ?>
    </tbody>
</table>
    <!-- Paginate -->
    <div>
        <?= $pagination; ?>
    </div>
</div>
</body>
</html>