<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
</head>
<body>
<h1><center>Product List</center></h1>
<form method="post" action="<?= base_url() ?>index.php/product/index">
    <input type="text" name="search" value="<?= $search ?>">
    <input type="submit" name="submit" value="Submit">
</form>
<a href="<?php echo site_url('product/add_new');?>" style="text-decoration: none;">Add Product</a><br/><br/>
<table border="1">
    <thead>
        <tr>
            <th>NO</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $count = $row + 1;
        foreach ($product->result() as $row) :
        ?>
    <tr>
        <th><?php echo $count;?></th>
        <td><?php echo $row->product_name;?></td>
        <td><?php echo number_format($row->product_price);?></td>
        <td>
            <a href="<?php echo site_url ('product/get_edit/'.$row->product_code);?>">Update</a>
            <a href="<?php echo site_url ('product/get_delete/'.$row->product_code);?>">Delete</a>
        </td>
    </tr>
        <?php 
        $count++;
        endforeach;
        ?>
    </tbody>
</table>
    <!-- Paginate -->
    <div>
        <?= $pagination; ?>
    </div>
</body>
</html>