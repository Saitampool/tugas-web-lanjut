<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete</title>
</head>
<body>
    <p><b>Klik Ok Untuk Menghapus <?php echo $product_name?></b></p>
    <form action="<?php echo site_url('product/delete/'.$product_code);?>">
        <button type="submit">OK</button>
    </form>
</body>
</html>