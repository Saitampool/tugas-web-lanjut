<?php

class Schedule_model extends CI_Model{

    function get_schedule($rowno, $rowperpage, $search = "") {

        $this->db->select('*');
        $this->db->from('schedule');

        if ($search != '') {
            $this->db->like('NoOrder', $search);
            $this->db->or_like('IdBed', $search);
            $this->db->or_like('Location', $search);
            $this->db->or_like('NoFasilitasOrderDetail', $search);
        }

        $result = $this->db->limit($rowperpage, $rowno)->get();
        return $result;
    }

    function get_schedule_count($search = '') {

        $this->db->select('*');
        $this->db->from('schedule');

        if ($search != '') {
            $this->db->like('NoOrder', $search);
            $this->db->or_like('IdBed', $search);
            $this->db->or_like('Location', $search);
            $this->db->or_like('NoFasilitasOrderDetail', $search);
        }

        $result = $this->db->count_all_results();
        return $result;
    }

    function save($NoOrder,$IdBed,$Location,$NoFasilitasOrderDetail){
        $data = array (
            'NoOrder' => $NoOrder,
            'IdBed' => $IdBed,
            'Location' => $Location,
            'NoFasilitasOrderDetail' => $NoFasilitasOrderDetail
        );
        $this->db->insert('schedule',$data);
    }

    function get_schedule_by_RNum($RNum){
        $query = $this->db->get_where('schedule', array('RNum' => $RNum));
        return $query;
    }

    function update($RNum,$NoOrder,$IdBed,$Location,$NoFasilitasOrderDetail) {
        $data = array(
            'NoOrder' => $NoOrder,
            'IdBed' => $IdBed,
            'Location' => $Location,
            'NoFasilitasOrderDetail' => $NoFasilitasOrderDetail
        );
        $this->db->where('RNum', $RNum);
        $this->db->update('schedule', $data);
    }

    function delete($RNum) {
        $this->db->where('RNum', $RNum);
        $this->db->delete('schedule');
    }
}