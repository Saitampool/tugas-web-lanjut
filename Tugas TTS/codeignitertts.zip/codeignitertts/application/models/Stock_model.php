<?php

class Stock_model extends CI_Model{

    function get_stock($rowno, $rowperpage, $search = "") {

        $this->db->select('*');
        $this->db->from('stockopnamedetail');

        if ($search != '') {
            $this->db->like('NoTransaksi', $search);
            $this->db->or_like('KodeItem', $search);
            $this->db->or_like('RealStock', $search);
            $this->db->or_like('IdLokasi', $search);
        }

        $result = $this->db->limit($rowperpage, $rowno)->get();
        return $result;
    }

    function get_stock_count($search = '') {

        $this->db->select('*');
        $this->db->from('stockopnamedetail');

        if ($search != '') {
            $this->db->like('NoTransaksi', $search);
            $this->db->or_like('KodeItem', $search);
            $this->db->or_like('RealStock', $search);
            $this->db->or_like('IdLokasi', $search);
        }

        $result = $this->db->count_all_results();
        return $result;
    }

    function save($NoTransaksi,$KodeItem,$RealStock,$IdLokasi){
        $data = array (
            'NoTransaksi' => $NoTransaksi,
            'KodeItem' => $KodeItem,
            'RealStock' => $RealStock,
            'IdLokasi' => $IdLokasi
        );
        $this->db->insert('stockopnamedetail',$data);
    }

    function get_stock_by_no_line($NoLine){
        $query = $this->db->get_where('stockopnamedetail', array('NoLine' => $NoLine));
        return $query;
    }

    function update($NoLine,$NoTransaksi,$KodeItem,$RealStock,$IdLokasi) {
        $data = array(
            'NoTransaksi' => $NoTransaksi,
            'KodeItem' => $KodeItem,
            'RealStock' => $RealStock,
            'IdLokasi' => $IdLokasi
        );
        $this->db->where('NoLine', $NoLine);
        $this->db->update('stockopnamedetail', $data);
    }

    function delete($NoLine) {
        $this->db->where('NoLine', $NoLine);
        $this->db->delete('stockopnamedetail');
    }
}