<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit New Stock</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
    <h1><center>Edit New Stock</center></h1>
    <div>
        <form action="<?php echo site_url ('stock/update');?>" method="post">
        <div class="form-group row">
            <label class="col-sm-2 col-form-label col-form-label-sm">Nomer Transaksi</label>
            <div class="col-sm-4">
            <input class="form-control form-control-sm" type="text" name="NoTransaksi" value="<?php echo $NoTransaksi;?>" placeholder="NoTransaksi">
            </div>
        </div><br>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label col-form-label-sm">Kode Item</label>
            <div class="col-sm-4">
            <input class="form-control form-control-sm" type="text" name="KodeItem" value="<?php echo $KodeItem;?>" placeholder="KodeItem">
            </div>
        </div><br>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label col-form-label-sm">Real Stock</label>
            <div class="col-sm-4">
            <input class="form-control form-control-sm" type="text" name="RealStock" value="<?php echo $RealStock;?>" placeholder="RealStock">
            </div>
        </div><br>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label col-form-label-sm">Id Lokasi</label>
            <div class="col-sm-4">
            <input class="form-control form-control-sm" type="text" name="IdLokasi" value="<?php echo $IdLokasi;?>" placeholder="IdLokasi">
            </div>
        </div><br>
        <input type="hidden" name="NoLine" value="<?php echo $NoLine?>">
        <button class="btn btn-primary btn-sm" type="submit">Submit</button>
        </form>
    </div>
</body>
</html>