<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
<h1><center>Stock List</center></h1>
<form method="post" action="<?= base_url() ?>index.php/stock/index">
    <div class="input-group">
        <div class="form-outline">
            <input id="form1" class="form-control" placeholder="Cari Stock" type="text" name="search" value="<?= $search ?>">
        </div>
        <div>
            <input class="btn btn-primary" type="submit" name="submit" value="Submit">
        </div>
    </div>
</form><br>
<a href="<?php echo site_url('stock/add_new');?>" class="btn btn-primary btn-sm">Add Stock</a><br/><br/>
<table class="table">
    <thead>
        <tr>
            <th>NO</th>
            <th>Nomer Transaksi</th>
            <th>Kode Item</th>
            <th>Real Stock</th>
            <th>Id Lokasi</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $count = $row + 1;
        foreach ($stockopnamedetail->result() as $row) :
        ?>
    <tr>
        <th><?php echo $count;?></th>
        <td><?php echo $row->NoTransaksi;?></td>
        <td><?php echo $row->KodeItem;?></td>
        <td><?php echo $row->RealStock;?></td>
        <td><?php echo $row->IdLokasi;?></td>
        <td>
            <a class="btn btn-secondary btn-sm" href="<?php echo site_url ('stock/get_edit/'.$row->NoLine);?>">Update</a>
            <a class="btn btn-secondary btn-sm" href="<?php echo site_url ('stock/get_delete/'.$row->NoLine);?>">Delete</a>
        </td>
    </tr>
        <?php 
        $count++;
        endforeach;
        ?>
    </tbody>
</table>
    <!-- Paginate -->
    <div>
        <?= $pagination; ?>
    </div><br>
    <!-- Pindah Tabel -->
    <div>
        <a href="http://localhost/codeignitertts/index.php/schedule" class="btn btn-primary btn-sm" role="button">Schedule</a>
    </div>
</body>
</html>