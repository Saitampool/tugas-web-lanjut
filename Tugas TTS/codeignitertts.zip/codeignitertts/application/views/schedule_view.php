<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
<h1><center>Schedule List</center></h1>
<form method="post" action="<?= base_url() ?>index.php/schedule/index">
    <div class="input-group">
        <div class="form-outline">
            <input id="form1" class="form-control" placeholder="Cari Jadwal" type="text" name="search" value="<?= $search ?>">
    </div>
    <div>
        <input class="btn btn-primary" type="submit" name="submit" value="Submit">
    </div>
    </div>
</form><br>
<a href="<?php echo site_url('schedule/add_new');?>" class="btn btn-primary btn-sm">Add Schedule</a><br/><br/>
<table class="table">
    <thead>
        <tr>
            <th>NO</th>
            <th>Nomer Order</th>
            <th>Id Bed</th>
            <th>Lokasi</th>
            <th>Detail Nomer Fasilitas Order</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $count = $row + 1;
        foreach ($schedule->result() as $row) :
        ?>
    <tr>
        <th><?php echo $count;?></th>
        <td><?php echo $row->NoOrder;?></td>
        <td><?php echo $row->IdBed;?></td>
        <td><?php echo $row->Location;?></td>
        <td><?php echo $row->NoFasilitasOrderDetail;?></td>
        <td>
            <a class="btn btn-secondary btn-sm" href="<?php echo site_url ('schedule/get_edit/'.$row->RNum);?>">Update</a>
            <a class="btn btn-secondary btn-sm" href="<?php echo site_url ('schedule/get_delete/'.$row->RNum);?>">Delete</a>
        </td>
    </tr>
        <?php 
        $count++;
        endforeach;
        ?>
    </tbody>
</table>
    <!-- Paginate -->
    <div>
        <?= $pagination; ?>
    </div><br>
    <!-- Pindah Tabel -->
    <div>
        <a href="http://localhost/codeignitertts/index.php/stock" class="btn btn-primary btn-sm" role="button">Stock</a>
    </div>
</body>
</html>