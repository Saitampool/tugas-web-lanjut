<?php
class Stock extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('stock_model');
    }

	function index($row_no = 0){

        // Search text
        $search_text = "";
        if ($this->input->post('submit') != NULL) {
            $search_text = $this->input->post('search');
            $this->session->set_userdata(array("search" => $search_text));
        } else {
            if ($this->session->userdata('search') != NULL) {
                $search_text = $this->session->userdata('search');
            }
        }

        // Row per page
        $row_per_page = 5;

        // Row position
        if ($row_no != 0) {
            $row_no = ($row_no - 1) * $row_per_page;
        }

        // Pagination Configuration
        // All records count
        $config['total_rows'] = $this->stock_model->get_stock_count($search_text);
        $config['base_url'] = base_url() . 'index.php/stock/index';
        $config['use_page_numbers'] = TRUE;
        $config['per_page'] = $row_per_page;

        // Initialize
        $this->pagination->initialize($config);

        $data['pagination'] = $this->pagination->create_links();

        // Get record
        $data['stockopnamedetail'] = $this->stock_model->get_stock($row_no, $row_per_page, $search_text);

        $data['row'] = $row_no;
        $data['search'] = $search_text;
        
        $this->load->view('stock_view',$data);

        // $data['product'] = $this->product_model->get_product();
		// $this->load->view('product_view',$data);
	}

    function add_new() {
        $this->load->view('add_stock_view');
    }

    function save() {
        $NoTransaksi = $this->input->post('NoTransaksi');
        $KodeItem = $this->input->post('KodeItem');
        $RealStock = $this->input->post('RealStock');
        $IdLokasi = $this->input->post('IdLokasi');
        $this->stock_model->save($NoTransaksi,$KodeItem,$RealStock,$IdLokasi);
        redirect('stock');
    }

    function get_edit(){
        $NoLine = $this->uri->segment(3);
        $result = $this->stock_model->get_stock_by_no_line($NoLine);
        if($result->num_rows() > 0) {
            $i = $result->row_array();
            $data = array(
                'NoLine' => $i['NoLine'],
                'NoTransaksi' => $i['NoTransaksi'],
                'KodeItem' => $i['KodeItem'],
                'RealStock' => $i['RealStock'],
                'IdLokasi' => $i['IdLokasi']
            );
            $this->load->view('edit_stock_view',$data);
        }else{
            echo "Data Was Not Found";
        }
    }

    function update(){
        $NoLine = $this->input->post('NoLine');
        $NoTransaksi = $this->input->post('NoTransaksi');
        $KodeItem = $this->input->post('KodeItem');
        $RealStock = $this->input->post('RealStock');
        $IdLokasi = $this->input->post('IdLokasi');
        $this->stock_model->update($NoLine,$NoTransaksi,$KodeItem,$RealStock,$IdLokasi);
        redirect('stock');
    }

    function get_delete(){
        $NoLine = $this->uri->segment(3);
        $result = $this->stock_model->get_stock_by_no_line($NoLine);
        if($result->num_rows() > 0) {
            $i = $result->row_array();
            $data = array(
                'NoLine' => $i['NoLine'],
                'NoTransaksi' => $i['NoTransaksi'],
                'KodeItem' => $i['KodeItem'],
                'RealStock' => $i['RealStock'],
                'IdLokasi' => $i['IdLokasi']
            );
            $this->load->view('delete_stock_view',$data);
        }else{
            echo "Data Was Not Found";
        }
    }

    function delete(){
        $NoLine = $this->uri->segment(3);
        $this->stock_model->delete($NoLine);
        redirect('stock');
    }
}