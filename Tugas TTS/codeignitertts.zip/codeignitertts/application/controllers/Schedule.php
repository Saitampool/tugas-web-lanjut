<?php
class Schedule extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('schedule_model');
    }

	function index($row_no = 0){

        // Search text
        $search_text = "";
        if ($this->input->post('submit') != NULL) {
            $search_text = $this->input->post('search');
            $this->session->set_userdata(array("search" => $search_text));
        } else {
            if ($this->session->userdata('search') != NULL) {
                $search_text = $this->session->userdata('search');
            }
        }

        // Row per page
        $row_per_page = 5;

        // Row position
        if ($row_no != 0) {
            $row_no = ($row_no - 1) * $row_per_page;
        }

        // Pagination Configuration
        // All records count
        $config['total_rows'] = $this->schedule_model->get_schedule_count($search_text);
        $config['base_url'] = base_url() . 'index.php/schedule/index';
        $config['use_page_numbers'] = TRUE;
        $config['per_page'] = $row_per_page;

        // Initialize
        $this->pagination->initialize($config);

        $data['pagination'] = $this->pagination->create_links();

        // Get record
        $data['schedule'] = $this->schedule_model->get_schedule($row_no, $row_per_page, $search_text);

        $data['row'] = $row_no;
        $data['search'] = $search_text;
        
        $this->load->view('schedule_view',$data);

        // $data['product'] = $this->product_model->get_product();
		// $this->load->view('product_view',$data);
	}

    function add_new() {
        $this->load->view('add_schedule_view');
    }

    function save() {
        $NoOrder = $this->input->post('NoOrder');
        $IdBed = $this->input->post('IdBed');
        $Location = $this->input->post('Location');
        $NoFasilitasOrderDetail = $this->input->post('NoFasilitasOrderDetail');
        $this->schedule_model->save($NoOrder,$IdBed,$Location,$NoFasilitasOrderDetail);
        redirect('schedule');
    }

    function get_edit(){
        $RNum  = $this->uri->segment(3);
        $result = $this->schedule_model->get_schedule_by_RNum($RNum);
        if($result->num_rows() > 0) {
            $i = $result->row_array();
            $data = array(
                'RNum' => $i['RNum'],
                'NoOrder' => $i['NoOrder'],
                'IdBed' => $i['IdBed'],
                'Location' => $i['Location'],
                'NoFasilitasOrderDetail' => $i['NoFasilitasOrderDetail']
            );
            $this->load->view('edit_schedule_view',$data);
        }else{
            echo "Data Was Not Found";
        }
    }

    function update(){
        $RNum  = $this->input->post('RNum');
        $NoOrder = $this->input->post('NoOrder');
        $IdBed = $this->input->post('IdBed');
        $Location = $this->input->post('Location');
        $NoFasilitasOrderDetail = $this->input->post('NoFasilitasOrderDetail');
        $this->schedule_model->update($RNum,$NoOrder,$IdBed,$Location,$NoFasilitasOrderDetail);
        redirect('schedule');
    }

    function get_delete(){
        $RNum  = $this->uri->segment(3);
        $result = $this->schedule_model->get_schedule_by_RNum($RNum);
        if($result->num_rows() > 0) {
            $i = $result->row_array();
            $data = array(
                'RNum' => $i['RNum'],
                'NoOrder' => $i['NoOrder'],
                'IdBed' => $i['IdBed'],
                'Location' => $i['Location'],
                'NoFasilitasOrderDetail' => $i['NoFasilitasOrderDetail']
            );
            $this->load->view('delete_schedule_view',$data);
        }else{
            echo "Data Was Not Found";
        }
    }

    function delete(){
        $RNum = $this->uri->segment(3);
        $this->schedule_model->delete($RNum);
        redirect('schedule');
    }
}