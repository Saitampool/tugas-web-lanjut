<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
</head>
<body>
<a href="<?php echo site_url('product/add_new');?>">Add Product</a><br/><br/>
<h1><center>Product List</center></h1>
<table>
    <thead>
        <tr>
            <th>NO</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $count = 0;
        foreach ($product->result() as $row) :
            $count++;
        ?>
    <tr>
        <th><?php echo $count;?></th>
        <td><?php echo $row->product_name;?></td>
        <td><?php echo number_format($row->product_price);?></td>
        <td>
            <a>Update</a>
            <a>Delete</a>
        </td>
    </tr>
        <?php endforeach;?>
    </tbody>
</table>

</body>
</html>